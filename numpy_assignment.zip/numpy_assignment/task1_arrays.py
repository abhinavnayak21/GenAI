# Task 1: Creating NumPy Arrays

import numpy as np

arr1 = np.arange(1, 11)

arr2 = np.arange(1, 10).reshape(3, 3)

#Array
arr3 = np.array([10, 20, 30, 40, 50])

#print arrays
print("1D Array:\n", arr1)
print("Shape:", arr1.shape)
print("Data type:", arr1.dtype)

print("\n2D Array:\n", arr2)
print("Shape:", arr2.shape)
print("Data type:", arr2.dtype)

print("\nArray from list:\n", arr3)
print("Shape:", arr3.shape)
print("Data type:", arr3.dtype)