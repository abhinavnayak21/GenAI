# Task 7: Mini Use Case - Sales Analysis

import numpy as np

sales = np.array([1200, 1500, 900, 2000, 1800, 1700, 1600])

print("Total Weekly Sales:", np.sum(sales))

print("Average Daily Sales:", np.mean(sales))

print("Highest Sales:", np.max(sales))
print("Lowest Sales:", np.min(sales))

print("Standard Deviation:", np.std(sales))

average = np.mean(sales)

print("Sales Above Average:", sales[sales > average])