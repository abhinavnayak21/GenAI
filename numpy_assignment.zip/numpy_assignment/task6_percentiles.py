# Task 6: Percentiles & Sorting

import numpy as np

marks = np.array([78, 85, 90, 66, 72, 88, 95, 60])

# Sort array
sorted_marks = np.sort(marks)

print("Sorted Marks:", sorted_marks)

# Percentiles
print("25th Percentile:", np.percentile(marks, 25))
print("50th Percentile:", np.percentile(marks, 50))
print("75th Percentile:", np.percentile(marks, 75))

# Count above average
average = np.mean(marks)

count = np.sum(marks > average)

print("Students above average:", count)